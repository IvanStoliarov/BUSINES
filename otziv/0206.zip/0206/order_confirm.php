<?php
require 'engine/db_connect.php';

if(isset($_POST['orders_quantity'])){
	if(isset($_SESSION['choosen_performers'])){
		unset($_SESSION['choosen_performers']);
	}
	$_SESSION['choosen_performers']=[];
	$result=mysqli_query($connection, "SELECT * FROM `USERS` WHERE STATUS='2' OR STATUS='4' ORDER BY GRANTED_ORDERS DESC");
	$orders_quantity=$_POST['orders_quantity'];
	$implementation_counter=1;
	while($res=mysqli_fetch_assoc($result)){
		if($implementation_counter>$orders_quantity){
			break;
		}
		$implementation_counter++;
		$_SESSION['choosen_performers'][]=$res['ID'];		
	}
}
mysqli_set_charset($connection, 'utf8');
$admin_data=mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM `ADMIN` WHERE ID='1'"));
?>
<!DOCTYPE html>
<html lang="ru">
<html>
<head>
	<title>Подтверждение заказа</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width" />
	
	<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
	<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">

</head>
<body>

	<header class="header" id="ex1">
		<div class="container">
			<nav class="header__nav">
				<a style="text-decoration: none;" href="../">
					<img src="img/logo.png" alt="Otziv video" class="logo  rubberBand">
				</a>
				<ul class="header__menu d-flex">
					<li class="menu__item">
						<div id="contacts_helper" style="position: fixed; background-color: rgba(127, 127, 127, 0.6); opacity: 0.95; padding: 10px; border-radius: 50%; color: white; text-align: center; visibility: hidden; right: 38%;">Нажмите чтобы оформить заказ <img src="img/point_right.png" height="25px"></div>
						<a id="performers_adder" style="position: relative;" href="<?php if(isset($_SESSION['logged_user'])){ echo '../order_confirm.php'; }else{ echo '#'; } ?>" class="menu__link"><img id="contacts_counter" src="img/add-contact.png" alt="Contact" class="user__red"><span style="visibility: <?php if(count($_SESSION['choosen_performers'])!=0){ echo 'visible'; }else{ echo 'hidden'; } ?>; position: absolute; left: 19px; top: 15px; color: white; text-decoration: none;" id="counter" class="kol__message"><?php echo count($_SESSION['choosen_performers']) ?></span></a>
							<div id="performers_adder_desc" style="position: fixed; background-color: grey; background-color: rgba(127,127,127, 0.6); opacity: 0.95; padding: 10px; border-radius: 2px; color: white; display: none; text-align: center;">
							<?php
							if(!isset($_SESSION['logged_user'])){
								echo 'Для того чтобы оформить ваш заказ<br>вы должны <a style="text-decoration: none; color: green;" href="../login.php?from=index.php">авторизоваться</a>';
							}elseif(count($_SESSION['choosen_performers'])<=0){
								echo 'Для того чтобы оформить заказ<br>вы должны <a style="text-decoration: none; color: green;" href="../login.php?from=index.php">выбрать исполнителей</a>';
							}else{
								$is_first=true;
								$desc_string="";
								foreach ($_SESSION['choosen_performers'] as $value) {
									$res=mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM `USERS` WHERE ID='".$value."'"))['LOGIN'];
									if($is_first){
										$desc_string=$desc_string.'Выбранные исполнители: '.$res;
										$is_first=false;
									}else{
										$desc_string=$desc_string.', '.$res;
									}
								}
								echo $desc_string;
							}
							?>
							</div>
					</li>
					<li class="menu__item">
						<a href="#" class="menu__link" id="notifications_button" style="position: relative;"><img src="img/info.png" alt="Info" class="user__red">
							<?php
							$result = mysqli_query($connection, "SELECT * FROM `MAILS` WHERE STATUS='2' AND TYPE='1' AND TO_ID='".$_SESSION['logged_user']['ID']."'");
							if(mysqli_num_rows($result)!=0){
								?>
								<span style="visibility: <?php if(mysqli_num_rows($result)!=0){ echo 'visible'; }else{ echo 'hidden'; } ?>; position: absolute; left: 18px; top: 15px; color: white; text-decoration: none;" id="notification-counter" class="kol__message"><?php echo mysqli_num_rows($result) ?></span>
								<?php
							}
							?>
						</a>
						<?php if(mysqli_num_rows($result)!=0){ ?>
							<div id="show_notifications" style="position: fixed; background-color: grey; background-color: rgba(127,127,127, 0.6); opacity: 0.95; padding: 10px; border-radius: 2px; color: white; display: none; text-align: center; max-width: 450px; text-align: left;">
								<?php
								while ($res=mysqli_fetch_assoc($result)) {
									?>
									<div class="notification_block" style="padding: 6px; background: white; border-radius: 4px; margin: 5px; color: black; position: relative;">
										<div class="notification_id" style="display:none"><?php echo $res['ID'] ?></div>
										<div style="word-wrap: break-word; left: 0; top: 0;"><?php echo $res['MESSAGE_TEXT'] ?></div><div style="font-size: smaller; right: 0; top: 0; margin-left: 7px; color: #1a7c18;"><?php echo $res['DATE'] ?></div>
									</div>
									<?php
								}
								?>
							</div>
						<?php }else{
							?>
							<div id="show_notifications" style="position: fixed; background-color: grey; background-color: rgba(127,127,127, 0.6); opacity: 0.95; padding: 10px; border-radius: 2px; color: white; display: none; text-align: center; max-width: 450px; text-align: left;">
								У вас пока нет уведомлений
							</div>
							<?php
						} ?>
					</li>
					<li class="menu__item">
						<?php if(isset($_SESSION['logged_user'])){ ?>
							<a id="exit_button" href="cabinet.php" class="menu__link"><img height="32px" width="32px;" style="border-radius: 50%;" src="<?php if(isset($_SESSION['logged_user'])){ echo getAvatarLink($_SESSION['logged_user']['ID']); } ?>" alt="Info" class="user__red"></a>
							<div id="exit_div" style="position: fixed; background-color: grey; background-color: rgba(127,127,127, 0.6); opacity: 0.95; padding: 10px; border-radius: 2px; color: white; display: none; text-align: center; max-width: 250px;">
								<a style="text-decoration: none; color: white;" href="../login.php">Выйти</a>
							</div>
						<?php }else{ ?>
							<a href="../login.php" class="menu__link" ><img src="img/web-log-in.png" alt="Exit" class="user__red"></a>
						<?php } ?>	
					</li>
				</ul>
					<div class="menu__switch">
						<a class="menu__switch-active" href="#">Главная</a>
						<a href="#">Каталог</a>
					</div>

				<!-- <div class="menu__mobile">
					<ul class="menu__list" id="menu">
						<li class="menu__item_m">
							<a href="#ex1" class="menu__link_m">Видео-отзывы</a>
						</li>
						<li class="menu__item_m">
							<a href="#ex3" class="menu__link_m">Видео-отзывы</a>
						</li>
						<li class="menu__item_m">
							<a href="#ex4" class="menu__link_m">Почему мы?</a>
						</li>
						<li class="menu__item_m">
							<a href="#ex6" class="menu__link_m menu__link_m_f">Быстрый заказ</a>
						</li>
						<div class="line__red"></div>
						<li class="menu__item_m">
							<a href="cabinet.php" class="menu__link_m" id="to_cabinet"><img src="img/user1.png" alt="User" class="user__red" id="cabinet"> <span id="cabinet" class="link__red">Мои заказы</span></a>
						</li>
					</ul>
					<img src="img/error.png" alt="cancel" class="img__cancel">
				</div> -->
			</nav>
		</div>
	</header><?php if(isset($_SESSION['logged_user'])&&isset($_SESSION['choosen_performers'])){ ?>
	<div class="confirmation_page_wrapper">
		<h2>Данные заказа</h2>
		<h5>Выбранные исполнители</h5>
		<div class="show_selected"><?php
		//Берем логины выбранных исполнителей из БД
		$first_checker=true;
		$sum=0;
		foreach ($_SESSION['choosen_performers'] as $value) {
			if($first_checker){
				echo mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM `USERS` WHERE ID='".$value."'"))['LOGIN'];
				$first_checker=false;
			}else{
				echo ", ".mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM `USERS` WHERE ID='".$value."'"))['LOGIN'];
			}
			$sum+=mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM `USERS` WHERE ID='".$value."'"))['PRICE'];
		}
    $user_balance=mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM `USERS` WHERE ID='".$_SESSION['logged_user']['ID']."'"))['BALANCE'];
    $amount_to_pay=$sum;
    if($user_balance<$sum){
        $amount_to_pay=$sum-$user_balance;
    }else{
        $amount_to_pay=0;
    }
		?></div><br><hr>
		<form id="order_to_payment" method="post" action="<?php if($amount_to_pay==0){ echo '../payment/proceed_from_balance.php'; }else{ echo '../payment/yandex/form/YandexMoney.php'; } ?>"><input type="hidden" name="price" value="<?php echo $amount_to_pay ?>">
        <input type="hidden" name="price_from_balance" value="<?php echo $sum-$amount_to_pay; ?>">
		<h5>Описание заказа</h5>
		<div class="order_desc">
			<textarea form="order_to_payment" style="width: 100%; position: relative;" name="text" class="order__video_text_pole" placeholder="Опишите максимально подробно задание для исполнителей"></textarea>
		</div>
		<?php
		if($amount_to_pay==0){
			?>
			<button form="order_to_payment" class="go_to_payment_button">Оплатить <?php echo $amount_to_pay ?> руб. с баланса</button>
			<?php
		}
		?>
		</form>
		<iframe src="https://money.yandex.ru/quickpay/button-widget?targets=%D0%9E%D0%BF%D0%BB%D0%B0%D1%82%D0%B0%20%D0%BD%D0%B0%20%D1%81%D0%B0%D0%B9%D1%82%D0%B5%20otziv.video&default-sum=<?php echo $amount_to_pay ?>&button-text=12&yamoney-payment-type=on&button-size=m&button-color=orange&successURL=http%3A%2F%2Fotziv.video%2Fpayment%2Fyandex%2Fevent%2FYandexMoney.php&quickpay=small&account=<?php echo $admin_data['YAMONEY_VALLET'] ?>&" width="184" height="36" frameborder="0" allowtransparency="true" scrolling="no"></iframe>

		<iframe src="https://money.yandex.ru/quickpay/button-widget?targets=%D0%9E%D0%BF%D0%BB%D0%B0%D1%82%D0%B0%20%D0%BD%D0%B0%20%D1%81%D0%B0%D0%B9%D1%82%D0%B5%20otziv.video&default-sum=<?php echo $amount_to_pay ?>&button-text=12&any-card-payment-type=on&button-size=m&button-color=orange&successURL=http%3A%2F%2Fotziv.video%2Fpayment%2Fyandex%2Fevent%2FYandexMoney.php&quickpay=small&account=<?php echo $admin_data['YAMONEY_VALLET'] ?>&" width="184" height="36" frameborder="0" allowtransparency="true" scrolling="no"></iframe>
	</div>
<?php }elseif(!isset($_SESSION['logged_user'])){ ?>
	<div style="top: 30%; position: absolute; margin: auto; width: 100%;" class="contractor" id="2"><h2 class="contractor__title">Для того, чтобы оформить заказ вы должны <a href="../signup.php" target="_blank">зарегистрироваться</a> или <a href="../login.php" target="_blank">войти</a></h2><a href="#" class="contractor__exit"></a><div>
<?php }else{ ?>
	<div style="top: 30%; position: absolute; margin: auto; width: 100%;" class="contractor" id="2"><h2 class="contractor__title">Вы не выбрали исполнителей!<br><br><a href="../ispolniteli.php">список исполнителей</a></h2><a href="#" class="contractor__exit"></a><div>
<?php } ?>	

	<footer class="footer">
		<div class="container">
			<div class="row">
					<?php
					$result=mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM `ADMIN` WHERE ID='1'"));
					if(($result['PHONE']!="")||($result['EMAIL']!="")||($result['TELEGRAM']!="")||($result['WHATSAPP']!="")||($result['VIBER']!="")){
					?>
				<div class="col-md-3 animated footer_a">
					<img src="img/contact.png" alt="contact" class="footer__img_contact">
					<h2 class="footer__contact">
						контакты
					</h2>
					<div class="footer__line"></div>
					<?php if($result['EMAIL']!=""){ ?>
					<img src="img/mail (1).png" alt="mail" class="footer__img_mail">
					<p class="footer__mail"><a style="text-decoration: none; color: white; top: -23px; position: relative;" href="mailto:<?php echo $result['EMAIL'] ?>"><?php echo $result['EMAIL'] ?></a></p>
					<?php } ?>
					<ul class="footer__contact_social d-flex">
						<?php if($result['TELEGRAM']!=""){ ?>
						<li class="footer__contact_item">
							<a href="#" class="footer__contact_link">
								<img src="img/telegram.png" alt="telegram" class="footer__contact_img">
							</a>
						</li>
						<?php } ?>
						<?php if($result['WHATSAPP']!=""){ ?>
						<li class="footer__contact_item">
							<a href="#" class="footer__contact_link">
								<img src="img/whatsapp.png" alt="whatsapp" class="footer__contact_img">
							</a>
						</li>
						<?php } ?>
						<?php if($result['VIBER']!=""){ ?>
						<li class="footer__contact_item">
							<a href="#" class="footer__contact_link">
								<img src="img/viber.png" alt="viber" class="footer__contact_img">
							</a>
						</li>
						<?php } ?>
					</ul>
				</div>
				<?php } ?>
				<div class="col-md-1"></div>
				<div class="col-md-4 animated footer_b">
					<img src="img/file.png" alt="message" class="footer__img_massage">
					<h3 class="footer__message">
						написать нам
					</h3>
					<form id="contact_form" method="POST" action="../engine/send_external_message.php">
						<input type="hidden" name="message_type" value="contact_form">
						<input form="contact_form" type="email" class="footer__form_email" name="email" placeholder="Ваш мейл">
						<textarea form="contact_form" type="text" class="footer__form_text" name="text" placeholder="Текст сообщения"></textarea>
						<button form="contact_form" class="footer__form_btn"><img src="img/mail.png" alt="" class="footer__img_mailf"></button>
					</form>
				</div>
				<div class="col-md-1"></div>
				<div class="col-md-3 animated footer_c">
					<img src="img/user.png" alt="user" class="footer__img_user">
					<h3 class="footer__user">
						пользователю
					</h3>
					<div class="footer__line footer__line_right"></div>
					<ul class="footer__menu">
						<li class="footer__item">
							<a href="#2" class="footer__link">Стать исполнителем</a>
						</li>
						<li class="footer__item">
							<a href="#ex6" class="footer__link">Заказать отзыв</a>
						</li>
						<li class="footer__item footer__item_a">
							<a href="../login.php" style="color: #dfe0e2; text-align: right; font-size: 18px; font-family: 'Open Sans', sans-serif; font-weight: 600; text-decoration: none;" ">Войти/зарегистрироваться</a>
						</li>
						<li class="footer__item">
							<a href="../login.php" class="footer__link">Авторизация через соцсети</a>
						</li>
					</ul>
					<ul class="footer__menu_social d-flex justify-content-end">
						<script src="//ulogin.ru/js/ulogin.js"></script>
						<div id="uLogin" data-ulogin="display=panel;theme=flat;fields=first_name,last_name,photo_big,bdate;providers=vkontakte,facebook,twitter;hidden=;redirect_uri=http%3A%2F%2Fotziv.video%2Fengine%2Fauthorisation_success.php;mobilebuttons=0;"></div>
					</ul>
				</div>
			</div>
		</div>
	</footer>

	<style type="text/css">
		.confirmation_page_wrapper{
			background-color: white;
			max-width: 80%;
			height: 60%;
			box-shadow: 4px 6px 10px #494949;
			top: 150px;
			position: relative;
			margin: auto;
			border-radius: 6px;
			padding: 20px;
		}
		.confirmation_page_wrapper:hover{
			box-shadow: 8px 9px 15px #494949;
		}
		body{
			background-color: grey;
		}
		.go_to_payment_button{
			right: 20px;
			bottom: 10px;
			position: absolute;
			margin: 4px;
			background-color: #42dfec;
			border-width: 0;
			border-radius: 4px;
			padding: 10px;
		}
		.go_to_payment_button:hover{
			background-color: orange;
		}
		.show_selected{
			padding-left: 35px;
			position: relative;
			border-width: 1px;
			border-color: grey;
			font-style: italic;
		}
		.order_desc{
			position: relative;
			right: 100px;
			left: 0px;
			max-width: 100%;
			width: auto;
		}
		footer{
			position: relative;
			bottom: -280px;
		}
	</style>

	<script
			  src="https://code.jquery.com/jquery-1.12.4.min.js"
			  integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ="
			  crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"
			  integrity="sha256-HmfY28yh9v2U4HfIXC+0D6HCdWyZI42qjaiCFEJgpo0="
			  crossorigin="anonymous"></script>
	<script type="text/javascript" src="slick/slick.min.js"></script>
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/js.js"></script>

</body>
</html>